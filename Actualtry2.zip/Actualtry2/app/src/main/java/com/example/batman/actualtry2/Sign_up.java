package com.example.batman.actualtry2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import net.sourceforge.jtds.jdbc.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Sign_up extends AppCompatActivity {

    Button mButton;
    EditText mEdit;
    TextView mText;
    Connection con;
    String un, pass, db, ip;
    String usernam, passwordd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        ip = "209.132.252.12";
        db = "DB_A2E042_AppDB";
        un = "DB_A2E042_AppDB_admin";
        pass = "rehan786";


        Button tomain = (Button) findViewById(R.id.skip_main);
        tomain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent main = new Intent(Sign_up.this, MainActivity.class);
                startActivity(main);
            }
        });

        mButton = (Button) findViewById(R.id.submit);
        mButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view1) {


                mEdit = (EditText) findViewById(R.id.input);
                mText = (TextView) findViewById(R.id.output);
                String test = mEdit.getText().toString();
                mText.setText(test);

                try {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    Class.forName("net.sourceforge.jtds.jdbc.Driver");
                   con = connectionclass("DB_A2E042_AppDB_admin", "rehan786", "DB_A2E042_AppDB", "209.132.252.12");        // Connect to database

                    Statement stmt = con.createStatement();
                    String userNameFLQuery = "insert into User_Table (userNameFL) values ('" + test + "')";
                    ResultSet rs = stmt.executeQuery(userNameFLQuery);




                                        /*
                try {
                    String driver = "net.sourceforge.jtds.jdbc.Driver";
                    Class.forName(driver).newInstance();
                    // Get a connection to a database and create a statement
                    String url = "jdbc:jtds:sqlserver://MSSQL: sql7001.site4now.net;database=DB_A2E042_AppDB;encrypt=false;instance=SQLEXPRESS;";
                    Connection conn = ;
                    Statement sta = conn.createStatement();

                    // Get first and last name and insert into db
                    String userNameFLQuery = "insert into User_Table (userNameFL) values ('" + test + "')";
                    boolean in1 = sta.execute(userNameFLQuery);
                } catch (Exception exc) {
                    exc.printStackTrace();
                }
            }
        }) ;*/





                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
                ;
            }

            @SuppressLint("NewApi")
            public Connection connectionclass(String user, String password, String database, String server) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                Connection connection = null;
                String ConnectionURL = null;
                try {
                    Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
                    ConnectionURL = "jdbc:jtds:sqlserver://sql7001.site4now.net;database=DB_A2E042_AppDB;user=DB_A2E042_AppDB_admin;password=rehan786";
//            ConnectionURL = "jdbc:jtds:sqlserver://192.168.1.9;database=msss;instance=SQLEXPRESS;Network Protocol=NamedPipes" ;


                    connection = DriverManager.getConnection(ConnectionURL);
                } catch (SQLException se) {
                    Log.e("error here 1 : ", se.getMessage());
                } catch (ClassNotFoundException e) {
                    Log.e("error here 2 : ", e.getMessage());
                } catch (Exception e) {
                    Log.e("error here 3 : ", e.getMessage());
                }
                return connection;
            }


        });
    }
}